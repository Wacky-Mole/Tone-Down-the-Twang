| `Version` | `Update Notes`    |
|-----------|-------------------|
| 1.0.0     | - Initial Release |
| 1.0.1     | - Update for 221.10 |